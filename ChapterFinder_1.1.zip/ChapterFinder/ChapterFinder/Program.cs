﻿using System;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace ChapterFinder
{
    class Program
    {
        static void SendMail(List<MailServer> mailHostPort)
        {
            string? answer = "";
            
            Console.WriteLine("Хотите отправить xml файл с главами по почте? 1 - да, 2 - просмотреть доступные домены, " +
                "другое - нет");
            answer = Console.ReadLine();

            // Пользователь нажал 2
            if (answer != null && answer.Length == 1 && answer[0] == '2')
            {
                Console.WriteLine("В данный момент доступны следующие домены: ");
                for (int i = 0; i < mailHostPort.Count; i++)
                    Console.WriteLine(i + ") " + mailHostPort[i].name);
                return;
            }

            // Пользователь нажал другое
            if (!(answer != null && answer.Length == 1 && answer[0] == '1'))
                return;

            // Пользователь нажал 1
            string filePath = AppDomain.CurrentDomain.BaseDirectory + "mail.xml";
            Console.WriteLine("Данные для отправки писем берутся из файла: " + filePath + 
                ". После нажатия любой клавиши начнётся чтение данных из указанного файла");
            Console.ReadKey();
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(Mail));
            Mail? mailParam;
            // десериализуем объект
            using (FileStream fs = new FileStream("mail.xml", FileMode.OpenOrCreate))
            {
                mailParam = xmlSerializer.Deserialize(fs) as Mail;
                Console.WriteLine("\nДанные успешно изъяты из mail.xml");
            }

            // Домен не совпал с доступными
            string userDomen = mailParam.from.Split('@')[mailParam.from.Split('@').Length - 1];
            bool isAvailable = false;
            int curHostPort = -1;
            for (int i = 0; i < mailHostPort.Count; i++)
                if (userDomen == mailHostPort[i].name)
                {
                    isAvailable = true;
                    curHostPort = i;
                }
                        
            if (!isAvailable)
            {
                Console.WriteLine("Не реализована работа с этим доменом");
                return;
            }

            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(mailParam.from); // Адрес отправителя
            mail.To.Add(new MailAddress(mailParam.to)); // Адрес получателя
            mail.Subject = "Поиск глав";
            mail.Body = "К письму прикреплен xml файл, в котором описаны все найденные главы в документе Word";
            mail.Attachments.Add(new Attachment(AppDomain.CurrentDomain.BaseDirectory + "Chapters.xml"));

            SmtpClient client = new SmtpClient();
            client.Host = mailHostPort[curHostPort].host;
            client.Port = mailHostPort[curHostPort].port;
            client.EnableSsl = true;
            client.Credentials = new NetworkCredential(mailParam.from, mailParam.passwordApplication); // Ваши логин и пароль
            client.Send(mail);
            Console.WriteLine("\nПисьмо отправлено!\n");
        }

        // Функция спрашивающая у пользователя путь до word файла
        static string GetWordPath()
        {
            bool isFileCorrect = false;
            string? filePath;
            do
            {
                Console.WriteLine("Какой word файл вы хотите изучить? Введите полный путь: ");
                filePath = Console.ReadLine();

                if (filePath == null || filePath == "")
                {
                    Console.WriteLine("Путь не получен");
                    continue;
                }

                if (!filePath.Contains(".docx"))
                {
                    Console.WriteLine("Указанный файл имеет не .docx расширение");
                    continue;
                }
                
                  
                FileInfo fileInfo = new FileInfo(filePath);
                if (!fileInfo.Exists)
                {
                    Console.WriteLine("Указанный файл не существует");
                    continue;
                }

                Console.WriteLine($"Выбран файл: {fileInfo.Name}");
                Console.WriteLine($"Размер: {fileInfo.Length} байт");
                isFileCorrect = true;
            }
            while (!isFileCorrect);
            
            return filePath;
        }

        static void SaveChaptersInXML(List<Chapter> chapters)
        {
            string filePath = AppDomain.CurrentDomain.BaseDirectory + "Chapters.xml";

            //// передаем в конструктор тип класса
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Chapter>));

            FileInfo fileInfo = new FileInfo(filePath);
            if (fileInfo.Exists)
                System.IO.File.WriteAllText(filePath, string.Empty);

            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
            {
                xmlSerializer.Serialize(fs, chapters);
                Console.WriteLine("Главы сериализованы и помещены в файл по пути: " + filePath);
            }
        }

        static void ChoosingActions(List<MailServer> mailHostPort)
        {
            bool isWorking = true;
            do
            {
                Console.WriteLine("Выберите действие: 1 - определить главы, 2 - переслать главы по электронной почте, другое - выход");
                string? answer = Console.ReadLine();

                // Пользователь нажал 1
                if (answer != null && answer.Length == 1 && answer[0] == '1')
                {
                    string filePath = GetWordPath();
                    Console.WriteLine("Начинаем поиск глав. Это может занять некоторое время.");
                    ChapterExtractor extractor = new ChapterExtractor(filePath);
                    List<Chapter> chapters = extractor.Get_NameID_Chapter();

                    // Сохранить номер главы и название главы в файл XML
                    SaveChaptersInXML(chapters);
                    continue;
                }

                // Пользователь нажал 2
                if (answer != null && answer.Length == 1 && answer[0] == '2')
                {
                    // Отправить созданный файл на почту
                    SendMail(mailHostPort);
                    continue;
                }

                isWorking = false;
            }
            while (isWorking);

            Console.WriteLine("\nДосвидания!\n");
        }

        static void Main(string[] args)
        {
            List<MailServer> mailHostPort = new List<MailServer>();
            mailHostPort.Add(new MailServer("smtp.mail.ru", 587, "mail.ru"));
            mailHostPort.Add(new MailServer("smtp.yandex.ru", 25, "yandex.ru"));
            // C:\Users\User\Downloads\_Приложение.docx
            // C:\Users\User\Downloads\_Тестовое задание.docx
            Console.WriteLine("Здравствуйте! Данная программа определяет главы в указанном документе " +
                "word с последующей пересылкой онных на электронную почту посредством xml файла");
            ChoosingActions(mailHostPort);
        }
    }
}