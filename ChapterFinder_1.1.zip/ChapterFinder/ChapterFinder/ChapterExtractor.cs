﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Text.RegularExpressions;

namespace ChapterFinder
{
    class ChapterExtractor
    {
        // Путь до файла .docx
        public string filePath = "";
        // Массив абзацев xml
        public List<string> paragraphsXML = new List<string>();
        // Массив абзацев только с текстом
        public List<string> paragraphs = new List<string>();
        // Название глав
        public List<string> chaptersName = new List<string>();
        // Порядковый номер глав
        public List<int> chaptersID = new List<int>();
        // Word документ
        Body body;

        // Конструктор
        public ChapterExtractor(string filePath)
        {
            this.filePath = filePath;

            // Open a WordprocessingDocument for editing using the filepath.
            WordprocessingDocument wordprocessingDocument = WordprocessingDocument.Open(filePath, false);
            // Assign a reference to the existing document body.
            body = wordprocessingDocument.MainDocumentPart.Document.Body;
            // Close the handle explicitly.
            wordprocessingDocument.Close();
        }

        // Деструктор
        ~ChapterExtractor()
        {
            body.ClearAllAttributes();
            paragraphs.Clear();
            paragraphsXML.Clear();
            chaptersID.Clear();
            chaptersName.Clear();
        }

        // Функция нахождения значения некоего атрибута
        // str - строка в которой ищется атрибут и значение
        // FirstString - открывающий тег атрибута
        // LastString - закрывающий тег атрибута
        public string Between(string str, string FirstString, string LastString)
        {
            if (str == "")
                return "";
            string finalString = "";
            int Pos1 = str.IndexOf(FirstString) + FirstString.Length;
            int Pos2 = str.IndexOf(LastString);
            if (Pos1 == FirstString.Length - 1 && Pos2 == -1)
                return "";
            // Если pos2 < pos1 -> открывающий операнд был дополнен <... ...>. В этом случае пересчитываем с добавлением
            if (Pos1 > Pos2 || Pos1 == FirstString.Length - 1)
            {
                FirstString = FirstString.Substring(0, FirstString.Length - 1) + " ";
                Pos1 = str.IndexOf(FirstString) + FirstString.Length;
                while (str[Pos1 - 1] != '>')
                    Pos1++;
                Pos2 = str.IndexOf(LastString);
            }
            
            finalString += str.Substring(Pos1, Pos2 - Pos1);
            return finalString;
        }

        // Функция нахождения глав в тексте документа Word
        public List<Chapter> Get_NameID_Chapter()
        {
            // 1) Разбить на абзацы
            // Так как не имею представления о иерархии -> нельзя сериализовать и осуществлять поиск базовыми средствами
            string bodyInnerXML = body.InnerXml;
            string paragraph = Between(bodyInnerXML, "<w:p>", "</w:p>");
            while (paragraph != "")
            {
                paragraphsXML.Add(paragraph);
                bodyInnerXML = bodyInnerXML.Remove(0, bodyInnerXML.IndexOf(paragraph + "</w:p>") + paragraph.Length + "</w:p>".Length);
                paragraph = Between(bodyInnerXML, "<w:p>", "</w:p>");
            }

            // 2) Вынуть весь текст из xml версии:
            //  <w:pPr><w:jc w:val="center" /><w:rPr><w:b /><w:sz w:val="32" /><w:szCs w:val="32" /></w:rPr></w:pPr>
            //  <w:r w:rsidRPr="00CB4AC9">
            //      <w:rPr><w:b /><w:sz w:val="32" /><w:szCs w:val="32" /></w:rPr>
            //      <w:t>Введение</w:t>
            //  </w:r>
            for (int i = 0; i < paragraphsXML.Count; i++)
            {
                paragraphs.Add("");
                string wordsXML = paragraphsXML[i];
                string words = Between(wordsXML, "<w:t>", "</w:t>");
                while (words != "")
                {
                    paragraphs[i] += words;
                    wordsXML = wordsXML.Remove(0, wordsXML.IndexOf(words + "</w:t>") + words.Length + "</w:t>".Length);
                    words = Between(wordsXML, "<w:t>", "</w:t>");
                }
            }

            // 3) Найти главы "Глава 1. "Что-то"" из каждого текста абзаца. Обязательно, чтобы абзац начинался с "Глава"
            Regex regex = new Regex(@"^Глава [1-9][0-9]*[.] .*");
            for (int i = 0; i < paragraphs.Count; i++)
            {
                MatchCollection matches = regex.Matches(paragraphs[i]);
                if (matches.Count > 0)
                {
                    string chapter = matches[0].Value;
                    int indexFirstPoint = chapter.IndexOf('.');
                    chaptersName.Add(chapter.Remove(0, indexFirstPoint + 2));
                    chaptersID.Add(Convert.ToInt32(chapter.Substring(6, indexFirstPoint - 6)));
                }
            }

            List<Chapter> result = new List<Chapter>();
            for (int i = 0; i < chaptersID.Count; i++)
                result.Add(new Chapter(chaptersID[i], chaptersName[i]));
            return result;
        }
    }
}
