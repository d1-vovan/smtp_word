﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChapterFinder
{
    [Serializable()]
    public class Chapter
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public Chapter() { }
        public Chapter(int id, string name)
        {
            ID = id;
            Name = name;
        }
    }
}
