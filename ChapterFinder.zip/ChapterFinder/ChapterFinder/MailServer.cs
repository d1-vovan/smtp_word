﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChapterFinder
{
    public class MailServer
    {
        public string host;
        public int port;
        public string name;

        public MailServer(string host, int port, string name)
        {
            this.host = host;
            this.port = port;
            this.name = name;
        }
    }
}
