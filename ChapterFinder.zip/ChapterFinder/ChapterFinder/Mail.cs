﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChapterFinder
{
    [Serializable()]
    public class Mail
    {
        public string from = "";
        public string to = "";
        public string passwordApplication = "";

        public Mail() { }
        public Mail(string from, string to, string passwordApplication)
        {
            this.from = from;
            this.to = to;
            this.passwordApplication = passwordApplication;
        }
    }
}
